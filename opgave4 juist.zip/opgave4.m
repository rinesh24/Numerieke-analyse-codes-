% =========================================================================
% Opdracht 4: Radiale Warmtegeleiding
% =========================================================================
clc; clear; close all;

% 1. Gegeven parameters
L = 1.20;           % Lengte van de pijp [m]
r_i = 0.030;        % Binnenradius [m]
r_o = 0.090;        % Buitenradius [m]
k0 = 0.20;          % Thermische geleidbaarheid [W/(m K)]
beta = 0.50;        % Parameter beta [-]
T_i = 200;          % Binnentemperatuur [°C]
T_o = 50;           % Buitentemperatuur [°C]

% 2. Functies (Regel 17-18)
k = @(r) k0 .* (1 + beta .* log(r / r_i));
f = @(r) 1 ./ (2 * pi * L * r .* k(r));

% 3. Numerieke oplossing met trapeziumregel (N = 100) (Regel 21-27)
N = 100;
r_num = linspace(r_i, r_o, N + 1);
h = (r_o - r_i) / N;
y = f(r_num);

Rth_num = (h / 2) * (y(1) + 2 * sum(y(2:end-1)) + y(end));
Q_num = (T_i - T_o) / Rth_num;

% 4. Analytische oplossing (Exact)
u_upper = 1 + beta * log(r_o / r_i);
Rth_exact = (1 / (2 * pi * L * k0 * beta)) * log(u_upper);
Q_exact = (T_i - T_o) / Rth_exact;

% 5. Fouten berekenen
err_Rth = abs((Rth_num - Rth_exact) / Rth_exact) * 100;
err_Q = abs((Q_num - Q_exact) / Q_exact) * 100;

% 6. Resultaten tonen
fprintf('R_th_num   = %.6f K/W\n', Rth_num);
fprintf('Q_num      = %.6f W\n', Q_num);
fprintf('R_th_exact = %.6f K/W\n', Rth_exact);
fprintf('Q_exact    = %.6f W\n', Q_exact);
fprintf('Fout R_th  = %.6e %%\n', err_Rth);